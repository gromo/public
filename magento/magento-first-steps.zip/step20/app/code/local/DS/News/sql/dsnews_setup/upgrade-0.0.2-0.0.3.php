<?php

//echo '<h1>Upgrade DS News to version 0.0.3</h1>';
//exit;

$installer = $this;
$tableNews = $installer->getTable('dsnews/table_news');

$installer->run("ALTER TABLE {$tableNews}
        ADD COLUMN `link` VARCHAR(255) NOT NULL AFTER `title`;");
$installer->run("ALTER TABLE {$tableNews}
        ADD UNIQUE KEY (`link`);");

foreach (Mage::getModel('dsnews/news')->getCollection() as $news) {
    try {
        $news->load($news->getId())->setDataChanges(true)->save();
    } catch (Exception $e) {
        $news->setId($news->getId())->setLink($news->getId())->save();
    }
}

$installer->endSetup();

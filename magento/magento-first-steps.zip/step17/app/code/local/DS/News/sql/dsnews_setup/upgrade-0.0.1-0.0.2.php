<?php

echo '<h1>Upgrade DS News to version 0.0.2</h1>';
exit;

$installer = $this;
$tableCategories = $installer->getTable('dsnews/table_categories');
$tableNews = $installer->getTable('dsnews/table_news');

$installer->startSetup();
$installer->run("DROP TABLE IF EXISTS {$tableCategories}");
$installer->run("CREATE TABLE {$tableCategories} (
        `category_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `title` VARCHAR(255) NOT NULL,

        PRIMARY KEY (`category_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

$installer->run("ALTER TABLE {$tableNews}
        ADD COLUMN `category_id` INT(11) UNSIGNED NOT NULL DEFAULT 0;");

$installer->endSetup();

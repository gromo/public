<?php

class DS_News_Adminhtml_NewsController extends Mage_Adminhtml_Controller_Action
{

    public function indexAction()
    {
        echo '<h1>News Module: Admin section</h1>';
    }

}
<?php

$installer = $this;
$tableNews = $installer->getTable('dsnews/table_news');

$installer->startSetup();
$installer->run("DROP TABLE IF EXISTS {$tableNews}");
$installer->run("CREATE TABLE {$tableNews} (
        `news_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `title` VARCHAR(255) NOT NULL,
        `content` TEXT NOT NULL,
        `created` DATETIME,

        PRIMARY KEY (`news_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

$installer->endSetup();
